loadNew = (newDiv) => (window.location.href = newDiv.getAttribute("new-ref"));
